const mongoose = require('mongoose');

const dietPlanSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  plan: { type: Array, required: true }, // Store the diet plan as an array of meals
});

module.exports = mongoose.model('DietPlan', dietPlanSchema);
