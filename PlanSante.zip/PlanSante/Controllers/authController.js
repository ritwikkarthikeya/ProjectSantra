const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const User = require('../models/User');

exports.getSignupPage = (req, res) => {
  res.render('signup', { errorMessage: null }); // This will render the signup page
};

exports.signup = async (req, res) => {
  const { email, password, confirmPassword } = req.body;

  if (password !== confirmPassword) {
    return res.render('signup', { errorMessage: 'Passwords do not match!' });
  }

  if (password.length < 8) {
    return res.render('signup', { errorMessage: 'Password must be at least 8 characters long!' });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ email, password: hashedPassword });
    await newUser.save();

    res.redirect('/signin');
  } catch (err) {
    res.render('signup', { errorMessage: 'Email is already registered!' });
  }
};

exports.getSigninPage = (req, res) => {
  res.render('signin', { errorMessage: null }); // This will render the signin page
};

exports.signin = async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.render('signin', { errorMessage: 'Invalid email or password!' });
    }

    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
    res.cookie('token', token, { httpOnly: true });
    res.redirect('/details');
  } catch (err) {
    res.render('signin', { errorMessage: 'Something went wrong!' });
  }
};

exports.logout = (req, res) => {
  res.clearCookie('token'); // Clear the token cookie
  res.redirect('/signin');  // Redirect to the signin page after logout
};
