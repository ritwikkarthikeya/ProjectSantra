const DietPlan = require('../models/DietPlan');

exports.getDietPlan = async (req, res) => {
  const userId = req.user.userId; // Extracted from the token

  // Fetch or generate the diet plan
  let dietPlan = await DietPlan.findOne({ userId });
  if (!dietPlan) {
    dietPlan = new DietPlan({ userId, plan: generateDietPlanLogic() });
    await dietPlan.save();
  }

  res.render('Details', { dietPlan: dietPlan.plan });
};

function generateDietPlanLogic() {
  // Example logic; replace with your actual diet plan generation logic
  return [
    { Food: 'Apple', Calories: 95, Proteins: 0.5, Carbs: 25, Fats: 0.3 },
    { Food: 'Chicken Breast', Calories: 165, Proteins: 31, Carbs: 0, Fats: 3.6 },
  ];
}
