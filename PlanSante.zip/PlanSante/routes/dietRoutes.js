const jwt = require('jsonwebtoken');
const express = require('express');
const router = express.Router();
const dietController = require('../Controllers/dietController');  // Ensure the path is correct

// Middleware for JWT authentication
const authenticateToken = (req, res, next) => {
  const token = req.cookies.token;

  if (!token) {
    // If no token, redirect to signin page
    return res.redirect('/signin');
  }

  // Verify JWT token
  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) {
      // If token is invalid, redirect to signin
      return res.redirect('/signin');
    }
    // Store decoded user information in the request object
    req.user = decoded;
    next();
  });
};

// Define routes and attach appropriate controllers
router.get('/details', authenticateToken, dietController.getDietPlan);

module.exports = router;
